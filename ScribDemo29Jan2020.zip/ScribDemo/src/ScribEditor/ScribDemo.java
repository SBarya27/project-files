
package ScribEditor;

import javax.swing.JFrame;
import javax.swing.UIManager;


public class ScribDemo {

  
    public static void main(String[] args) throws Exception {
        //Below line was added by Julia
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        ScribPadGui obj = new ScribPadGui();
        obj.setBounds(0, 0, 600, 500);
        obj.setTitle("Scrib");
        obj.setResizable(false);
        obj.setVisible(true);
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
