/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ScribEditor;

import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.StyledEditorKit;

/**
 *
 * @author robertsonbrinker
 */
public class UppercaseAction extends StyledEditorKit.StyledTextAction{
    
    public UppercaseAction() {
        super("font-uppercase");
    }
    
    public void actionPerformed(ActionEvent e) {
        JEditorPane editor = getEditor(e);
        if (editor != null) {
            StyledEditorKit kit = getStyledEditorKit(editor);
            MutableAttributeSet attr = kit.getInputAttributes();
            String upperText = editor.getSelectedText().toUpperCase();
            editor.replaceSelection(upperText);
            setCharacterAttributes(editor, attr, false);
        }
    }

    
}
